package com.contr.agent.controller;

import java.util.List;

import org.jooq.conf.Settings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.contr.agent.techclass.CustomerClass;

import jooqdata.tables.Customer;
import com.contr.agent.service.CustomerService;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;




@SpringBootApplication
@RestController
@RequestMapping("/customers")

public class CustomerController {

    @Autowired
    private CustomerService service;
    @PostMapping
    public String addCustomer(@RequestBody CustomerClass customer){
        service.insertCustomer(customer);
        return "Customer added...";
    }
    @GetMapping
    public List<jooqdata.tables.pojos.Customer> getCustomers(){
        return service.getCustomers();
    }
    @PutMapping
    public String updateCustomer(@RequestParam("customerCode") String customerCode, @RequestParam("columnName") String columnName, @RequestParam("newValue") String newValue){
        service.updateCustomer(customerCode, columnName, newValue);
        return columnName;
    }
    @DeleteMapping
    public String deleteCustomer(@RequestBody jooqdata.tables.pojos.Customer customer){
        service.deleteCustomer(customer);
        return "Customer deleted...";
    }
}
