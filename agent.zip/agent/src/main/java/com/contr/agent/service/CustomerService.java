package com.contr.agent.service;

import java.util.List;

import org.jooq.DSLContext;
import org.jooq.Field;
import org.jooq.Table;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

import com.contr.agent.ContragentApplication;
import com.contr.agent.techclass.CustomerClass;

import jooqdata.Tables;
import jooqdata.tables.pojos.Customer;
@Service
public class CustomerService {
    @Autowired
    private DSLContext dslContext;

    public void insertCustomer(CustomerClass custom){ 
        dslContext.insertInto(Tables.CUSTOMER, Tables.CUSTOMER.CUSTOMER_CODE, Tables.CUSTOMER.CUSTOMER_NAME, Tables.CUSTOMER.CUSTOMER_INN, Tables.CUSTOMER.CUSTOMER_KPP, 
        Tables.CUSTOMER.CUSTOMER_LEGAL_ADDRESS, Tables.CUSTOMER.CUSTOMER_POSTAL_ADDRESS, Tables.CUSTOMER.CUSTOMER_EMAIL, Tables.CUSTOMER.CUSTOMER_CODE_MAIN, Tables.CUSTOMER.IS_ORGANIZATION, Tables.CUSTOMER.IS_PERSON)
            .values(custom.getccode(), custom.getcname(), custom.getcinn(), custom.getckpp(), custom.getcla(), custom.getcpa(), custom.getce(), custom.getccodemain(), custom.getcisorg(), custom.getcisper())
            .execute();
    }
    
    public List<Customer> getCustomers(){
        return dslContext.selectFrom(Tables.CUSTOMER).fetchInto(Customer.class);
    }

    public void updateCustomer(String customerCode, String columnName, String newValue){
        Field<String> field = Tables.CUSTOMER.field(columnName, String.class);
        dslContext.update(Tables.CUSTOMER).set(field, newValue).where(Tables.CUSTOMER.CUSTOMER_CODE.eq(customerCode)).execute();
    }

    public void deleteCustomer(Customer customer){
        dslContext.deleteFrom(Tables.CUSTOMER).where(Tables.CUSTOMER.CUSTOMER_CODE.eq(customer.getCustomerCode())).execute();
    }

    public static void main(String[] args) {
		SpringApplication.run(ContragentApplication.class, args);
	}
}
