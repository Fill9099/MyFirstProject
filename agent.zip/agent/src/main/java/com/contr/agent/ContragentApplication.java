package com.contr.agent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ContragentApplication {

	public static void main(String[] args) {
		SpringApplication.run(ContragentApplication.class, args);
	}

}

