package com.contr.agent.techclass;

public class CustomerClass {
    private String ccode;
    private String cname;
    private String cinn;
    private String ckpp;
    private String cla;
    private String cpa;
    private String ce;
    private String ccodemain;
    private boolean cisorg;
    private boolean cisper;
    public String getccode() {
        return ccode;
    }
    public String getcname() {
        return cname;
    }
    public String getcinn() {
        return cinn;
    }
    public String getckpp() {
        return ckpp;
    }
    public String getcla() {
        return cla;
    }
    public String getcpa() {
        return cpa;
    }
    public String getce() {
        return ce;
    }
    public String getccodemain() {
        return ccodemain;
    }
    public boolean getcisorg() {
        return cisorg;
    }
    public boolean getcisper() {
        return cisper;
    }
}
